package com.progandro.ug2_progandro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class MainActivity : AppCompatActivity() {
    var firestore: FirebaseFirestore? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firestore = FirebaseFirestore.getInstance()

        val edtJudul = findViewById<EditText>(R.id.edtJudul)
        val edtTanggalPinjam = findViewById<EditText>(R.id.edtTanggalPinjam)
        val edtNoKTP = findViewById<EditText>(R.id.edtNoKTP)
        val btnPinjam = findViewById<Button>(R.id.btnPinjam)
        val btnEdit = findViewById<Button>(R.id.btnEdit)
        val txvOutput = findViewById<TextView>(R.id.txvOutput)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val btnCari = findViewById<Button>(R.id.btnCari)

        fun reload() {
            firestore?.collection("rental")?.get()?.addOnSuccessListener { data ->
                var output = ""
                for (hasil in data) {
                    output += "\n${hasil["namaKendaraan"]} - ${hasil["tanggalPinjam"]} - ${hasil["noKTP"]}"
                }
                txvOutput.text = output
            }
        }
            reload()
            btnPinjam.setOnClickListener {

                val rental = rental(
                    edtJudul.text.toString(),
                    edtTanggalPinjam.text.toString(),
                    edtNoKTP.text.toString()
                )
                edtJudul.setText("")
                edtTanggalPinjam.setText("")
                edtNoKTP.setText("")
                firestore?.collection("rental")?.add(rental)
                reload()

            }

            btnDelete.setOnClickListener {
                firestore?.collection("rental")?.get()?.addOnSuccessListener { data ->
                    for (hasil in data) {
                        if (edtJudul.text.toString() == hasil["namaKendaraan"]) {
                            firestore?.collection("rental")!!.document(hasil.id).delete()
                            edtJudul.setText("")
                            edtTanggalPinjam.setText("")
                            edtNoKTP.setText("")
                            reload()
                        }
                    }
                }
            }

            btnEdit.setOnClickListener {
                firestore?.collection("rental")?.get()?.addOnSuccessListener { data ->
                    for (hasil in data) {
                        if (edtJudul.text.toString() == hasil["namaKendaraan"]) {
                            firestore?.collection("rental")!!.document(hasil.id).update(mapOf("namaKendaraan" to edtJudul.text.toString(), "tanggalPinjam" to edtTanggalPinjam.text.toString(), "noKTP" to edtNoKTP.text.toString()))
                            edtJudul.setText("")
                            edtTanggalPinjam.setText("")
                            edtNoKTP.setText("")
                            reload()
                        }
                    }
                }
            }
            btnCari.setOnClickListener {
                firestore?.collection("rental")?.get()?.addOnSuccessListener { data ->
                    for (hasil in data) {
                        if (edtJudul.text.toString() == hasil["namaKendaraan"]) {
                            edtTanggalPinjam.setText(hasil["tanggalPinjam"].toString())
                            edtNoKTP.setText(hasil["noKTP"].toString())
                            reload()
                        }
                    }
                }
            }
        }
    }