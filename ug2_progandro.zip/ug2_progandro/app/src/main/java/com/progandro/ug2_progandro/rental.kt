package com.progandro.ug2_progandro

data class rental(val namaKendaraan: String, val tanggalPinjam: String, val noKTP: String)