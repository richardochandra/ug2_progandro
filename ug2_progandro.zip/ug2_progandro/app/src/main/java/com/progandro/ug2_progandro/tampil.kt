package com.progandro.ug2_progandro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class tampil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tampil)
    }
}